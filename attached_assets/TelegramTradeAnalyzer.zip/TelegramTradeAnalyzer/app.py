import os
import logging
import json
import requests
import threading
from flask import Flask, request, jsonify, render_template, redirect, url_for
from telegram import Bot, Update
from telegram.ext import Updater, Dispatcher, CommandHandler, MessageHandler, Filters
from config import (
    TELEGRAM_BOT_TOKEN, 
    COINGECKO_API_KEY, 
    COINGECKO_API_URL, 
    MISTRAL_API_KEY, 
    MISTRAL_API_URL,
    CRYPTOCURRENCIES
)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "crypto_telegram_mini_app")

# Initialize Telegram bot
bot = Bot(token=TELEGRAM_BOT_TOKEN)
updater = Updater(token=TELEGRAM_BOT_TOKEN, use_context=True)
dispatcher = updater.dispatcher

# CoinGecko API Headers
coingecko_headers = {
    "x-cg-api-key": COINGECKO_API_KEY
}

# ---------------------- API Functions ----------------------

def get_crypto_market_data():
    """Fetch cryptocurrency market data from CoinGecko API"""
    try:
        crypto_ids = "bitcoin,ethereum,binancecoin,cardano,solana,ripple,polkadot,dogecoin,avalanche-2,chainlink"
        url = f"{COINGECKO_API_URL}/simple/price?ids={crypto_ids}&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true"
        
        response = requests.get(url, headers=coingecko_headers, timeout=5)
        if response.status_code == 429:
            # Rate limit handling
            return {"error": "Rate limit exceeded. Please try again later."}
        response.raise_for_status()
        return response.json()
    except requests.exceptions.Timeout:
        return {"error": "Request timed out. Please try again."}
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching market data: {e}")
        return {"error": "Unable to fetch market data"}

def get_crypto_detail(crypto_id):
    """Fetch detailed information about a specific cryptocurrency"""
    try:
        # Build API URL
        url = f"{COINGECKO_API_URL}/coins/{crypto_id}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false"
        
        # Send request
        response = requests.get(url, headers=coingecko_headers)
        response.raise_for_status()
        
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching crypto detail: {e}")
        return {"error": str(e)}

def get_market_analysis(prompt):
    """Get market analysis from Mistral AI API"""
    try:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {MISTRAL_API_KEY}"
        }
        
        data = {
            "model": "mistral-tiny",
            "messages": [
                {"role": "system", "content": "You are a cryptocurrency market analyst specializing in Injective Protocol (INJ) and other cryptocurrencies. Prioritize information about INJ when relevant to the query. Provide concise, informative analysis based on the user's query with a focus on Injective's technology, price trends, and market position."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7,
            "max_tokens": 800
        }
        
        response = requests.post(MISTRAL_API_URL, headers=headers, json=data)
        response.raise_for_status()
        
        result = response.json()
        return result["choices"][0]["message"]["content"]
    except requests.exceptions.RequestException as e:
        logger.error(f"Error with Mistral API: {e}")
        return f"Sorry, I couldn't generate analysis at this time. Error: {str(e)}"

# ---------------------- Telegram Bot Handlers ----------------------

def start(update, context):
    """Handle /start command"""
    user = update.message.from_user
    
    # Just provide a simple welcome message without buttons for now
    update.message.reply_text(
        f"Hello {user.first_name}! Welcome to Inject AI - your Injective Protocol and crypto market analysis app.\n\n"
        f"You can interact with me directly using these commands:\n\n"
        f"📊 /market - Show current crypto prices\n"
        f"🔍 /analysis [question] - Get INJ market analysis\n\n"
        f"Ask me anything about INJ or other cryptocurrencies!"
    )

def market_command(update, context):
    """Handle /market command"""
    market_data = get_crypto_market_data()
    
    if "error" in market_data:
        update.message.reply_text(f"Error fetching market data: {market_data['error']}")
        return
    
    message = "📊 *Current Crypto Market Prices* 📊\n\n"
    
    # First display INJ if it exists
    if "injective" in market_data:
        inj_data = market_data["injective"]
        price = inj_data.get("usd", 0)
        change_24h = inj_data.get("usd_24h_change", 0)
        
        # Format the change with arrow
        change_str = "🔴" if change_24h < 0 else "🟢"
        
        message += "🌟 *FEATURED: Injective Protocol (INJ)*\n"
        message += f"💰 ${price:,.2f}\n"
        message += f"{change_str} {abs(change_24h):.2f}% (24h)\n\n"
    
    # Then display a few others (limit to 3 for clean display)
    count = 0
    for crypto, data in market_data.items():
        if crypto == "injective":
            continue  # Skip INJ as it's already displayed
        
        if count >= 3:
            break  # Only show 3 additional cryptos
            
        price = data.get("usd", 0)
        change_24h = data.get("usd_24h_change", 0)
        
        # Format the change with arrow
        change_str = "🔴" if change_24h < 0 else "🟢"
        
        message += f"*{crypto.title()}*\n"
        message += f"💰 ${price:,.2f}\n"
        message += f"{change_str} {abs(change_24h):.2f}% (24h)\n\n"
        count += 1
    
    # Add a note about getting more info
    message += "For more detailed market data and charts, visit the Inject AI web app."
    
    update.message.reply_text(
        message, 
        parse_mode="Markdown"
    )

def analysis_command(update, context):
    """Handle /analysis command"""
    if not context.args:
        # If no question provided, suggest common INJ analysis topics
        update.message.reply_text(
            "Please provide a question for market analysis.\n\n"
            "Example questions about Injective Protocol (INJ):\n"
            "• /analysis What is the current outlook for INJ?\n"
            "• /analysis How does INJ compare to other DeFi platforms?\n"
            "• /analysis What factors are influencing INJ price?\n\n"
            "You can also ask me questions directly about INJ."
        )
        return
    
    query = " ".join(context.args)
    analysis = get_market_analysis(query)
    
    update.message.reply_text(
        f"*Analysis:*\n\n{analysis}", 
        parse_mode="Markdown"
    )

def text_handler(update, context):
    """Handle regular text messages"""
    message_text = update.message.text
    
    # Check if message mentions INJ or Injective Protocol
    inj_mentioned = any(term in message_text.lower() for term in ["inj", "injective", "inject"])
    
    if message_text.lower().startswith(("what", "how", "why", "when", "is", "will", "can", "could", "should")) or inj_mentioned:
        # Looks like a question or mentions INJ, process it as market analysis
        analysis = get_market_analysis(message_text)
        
        update.message.reply_text(
            f"*Analysis:*\n\n{analysis}", 
            parse_mode="Markdown"
        )
    else:
        # Default response
        update.message.reply_text(
            "I can help you with crypto market data and analysis, with a focus on Injective Protocol (INJ).\n\n"
            "Try these commands:\n"
            "📊 /market - Show current crypto prices\n"
            "🔍 /analysis [question] - Get INJ market analysis\n\n"
            "Or simply ask me questions about INJ or Injective Protocol!"
        )

# Define webapp command handler
def webapp_command(update, context):
    """Handle /webapp command to directly open the web app"""
    update.message.reply_text(
        "Sorry, the web app integration is currently being updated. "
        "In the meantime, you can use all of the bot's features directly here:\n\n"
        "📊 /market - Show current crypto prices\n"
        "🔍 /analysis [question] - Get INJ market analysis\n\n"
        "Or simply ask me questions about INJ or Injective Protocol!"
    )

# Add handlers to the dispatcher
dispatcher.add_handler(CommandHandler("start", start))
dispatcher.add_handler(CommandHandler("market", market_command))
dispatcher.add_handler(CommandHandler("analysis", analysis_command))
dispatcher.add_handler(CommandHandler("webapp", webapp_command))
dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, text_handler))

# ---------------------- Flask Web Routes ----------------------

@app.route(f"/{TELEGRAM_BOT_TOKEN}", methods=["POST"])
def telegram_webhook():
    """Handle Telegram webhook requests"""
    if request.method == "POST":
        try:
            update = Update.de_json(request.get_json(force=True), bot)
            dispatcher.process_update(update)
        except Exception as e:
            logger.error(f"Error processing webhook: {e}")
    
    return "OK"

@app.route("/set_webhook")
def set_webhook():
    """Set the Telegram webhook"""
    # Get the URL from the request or use a default
    webhook_url = request.args.get('url', '')
    if not webhook_url:
        # If no URL is provided, assume the current host
        host = request.host_url.rstrip('/')
        webhook_url = f"{host}/{TELEGRAM_BOT_TOKEN}"
    
    try:
        s = bot.setWebhook(webhook_url)
        if s:
            return f"Webhook set to {webhook_url}"
        else:
            return "Failed to set webhook"
    except Exception as e:
        return f"Error setting webhook: {str(e)}"

@app.route("/webhook_info")
def webhook_info():
    """Get the current webhook information"""
    try:
        info = bot.getWebhookInfo()
        return str(info)
    except Exception as e:
        return f"Error getting webhook info: {str(e)}"

@app.route("/bot_info")
def bot_info():
    """Show information about the bot and setup instructions"""
    host = request.host_url.rstrip('/')
    webhook_url = f"{host}/{TELEGRAM_BOT_TOKEN}"
    
    return f"""
    <html>
    <head>
        <title>Inject AI Bot Setup</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }}
            .container {{ max-width: 800px; margin: 0 auto; }}
            h1 {{ color: #333; }}
            h2 {{ color: #555; margin-top: 20px; }}
            pre {{ background-color: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }}
            .btn {{ display: inline-block; background-color: #4CAF50; color: white; padding: 10px 15px; 
                  text-decoration: none; border-radius: 4px; margin: 10px 0; }}
            .warn {{ color: #ff6600; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Inject AI Telegram Bot Setup</h1>
            <p>This page provides information for setting up the Inject AI Telegram bot.</p>
            
            <h2>Bot Information</h2>
            <ul>
                <li><strong>Bot Username:</strong> @{bot.get_me().username}</li>
                <li><strong>Bot ID:</strong> {bot.get_me().id}</li>
            </ul>
            
            <h2>Webhook Configuration</h2>
            <p>To set up the bot webhook, use this URL:</p>
            <pre>{webhook_url}</pre>
            
            <p>You can set the webhook by clicking this button:</p>
            <a href="/set_webhook" class="btn">Set Webhook</a>
            
            <p>To check the current webhook status:</p>
            <a href="/webhook_info" class="btn">Check Webhook Status</a>
            
            <h2>Manual Setup</h2>
            <p>If you prefer manual setup, you can use the Telegram Bot API directly:</p>
            <pre>https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/setWebhook?url={webhook_url}</pre>
            
            <h2>Bot Commands</h2>
            <p>The bot supports these commands:</p>
            <ul>
                <li><strong>/start</strong> - Initialize the bot and get welcome message</li>
                <li><strong>/market</strong> - Get cryptocurrency market data</li>
                <li><strong>/analysis</strong> - Get AI-powered market analysis</li>
                <li><strong>/webapp</strong> - Open the Inject AI web app</li>
            </ul>
            
            <p class="warn">Note: For the bot to work properly, your server must be accessible from the internet and have a valid SSL certificate (HTTPS).</p>
        </div>
    </body>
    </html>
    """

@app.route("/")
def index():
    """Main route for the Telegram Mini App"""
    return render_template("index.html")

@app.route("/market")
def market():
    """Route to display cryptocurrency market data"""
    market_data = get_crypto_market_data()
    
    if "error" in market_data:
        return render_template("market.html", error=market_data["error"])
    
    return render_template("market.html", market_data=market_data)

@app.route("/market/<crypto_id>")
def market_detail(crypto_id):
    """Route to display detailed information about a specific cryptocurrency"""
    try:
        crypto_data = get_crypto_detail(crypto_id)
        if isinstance(crypto_data, dict) and "error" in crypto_data:
            return render_template("market_detail.html", error=crypto_data["error"])
        return render_template("market_detail.html", crypto=crypto_data)
    except Exception as e:
        return render_template("market_detail.html", error=str(e))

@app.route("/analysis", methods=["GET", "POST"])
def analysis():
    """Route to handle market analysis requests"""
    if request.method == "POST":
        question = request.form.get("question", "").strip()
        if not question:
            return render_template("analysis.html", error="Please enter a question")
        try:
            analysis_text = get_market_analysis(question)
            return render_template("analysis.html", question=question, analysis=analysis_text)
        except Exception as e:
            logger.error(f"Analysis error: {e}")
            return render_template("analysis.html", error="Unable to generate analysis. Please try again.")
    return render_template("analysis.html")

@app.route("/api/market_data")
def api_market_data():
    """API endpoint to fetch cryptocurrency market data"""
    market_data = get_crypto_market_data()
    return jsonify(market_data)

@app.route("/api/crypto/<crypto_id>")
def api_crypto_detail(crypto_id):
    """API endpoint to fetch detailed information about a specific cryptocurrency"""
    crypto_data = get_crypto_detail(crypto_id)
    return jsonify(crypto_data)

@app.route("/api/analysis", methods=["POST"])
def api_analysis():
    """API endpoint to get market analysis"""
    data = request.get_json()
    if not data or "question" not in data:
        return jsonify({"error": "Please provide a question"}), 400
    
    analysis_text = get_market_analysis(data["question"])
    return jsonify({"analysis": analysis_text})

# ---------------------- Bot Polling Thread ----------------------

@app.route("/start_bot")
def start_bot():
    """Start the bot in polling mode"""
    try:
        # First remove any existing webhook
        bot.deleteWebhook()
        
        # Create a new thread for the bot polling
        def polling_thread():
            logger.info("Starting Telegram bot polling...")
            updater.start_polling()
            updater.idle()
        
        bot_thread = threading.Thread(target=polling_thread)
        bot_thread.daemon = True  # Make the thread daemon so it exits when the main app exits
        bot_thread.start()
        
        return "Bot started in polling mode. It will now respond to messages sent directly to it."
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
        return f"Error starting bot: {str(e)}"

# Start the bot polling when the app starts
# Use a thread to start the bot so it doesn't block the main Flask app
if os.environ.get('START_BOT_POLLING', 'true').lower() == 'true':
    bot_thread = threading.Thread(target=lambda: updater.start_polling())
    bot_thread.daemon = True
    bot_thread.start()
    logger.info("Bot polling started in background thread")
