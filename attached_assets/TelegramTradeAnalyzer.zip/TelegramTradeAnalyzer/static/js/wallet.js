
// Keplr wallet connection handler
let isWalletConnected = false;
let walletAddress = '';

async function connectKeplrWallet() {
    try {
        // Check if Keplr is installed
        if (!window.keplr) {
            alert("Please install Keplr wallet extension first!");
            window.open("https://www.keplr.app/", '_blank');
            return false;
        }

        // Request connection to Injective chain
        try {
            await window.keplr.enable("injective-1");
        } catch (error) {
            console.error("Failed to enable Keplr:", error);
            alert("Failed to connect to Injective chain. Please try again.");
            return false;
        }

        // Get the offline signer
        const offlineSigner = window.keplr.getOfflineSigner("injective-1");

        // Get user's account
        const accounts = await offlineSigner.getAccounts();

        if (accounts && accounts.length > 0) {
            walletAddress = accounts[0].address;
            isWalletConnected = true;

            // Update UI elements
            const walletBtn = document.getElementById('wallet-button');
            if (walletBtn) {
                walletBtn.innerHTML = `Connected: ${walletAddress.substring(0, 6)}...${walletAddress.substring(walletAddress.length - 4)}`;
            }

            // Show main content and hide wallet connection section
            const mainContent = document.getElementById('main-content');
            const walletConnect = document.getElementById('wallet-connect');
            
            if (mainContent) mainContent.style.display = 'block';
            if (walletConnect) walletConnect.style.display = 'none';

            return true;
        }
    } catch (error) {
        console.error("Wallet connection error:", error);
        alert("Failed to connect wallet. Please try again.");
        return false;
    }
}

// Initialize wallet connection
document.addEventListener('DOMContentLoaded', () => {
    const connectWalletBtn = document.getElementById('connect-wallet');
    if (connectWalletBtn) {
        connectWalletBtn.addEventListener('click', connectKeplrWallet);
    }

    // Check for existing connection
    if (window.keplr) {
        window.keplr.getOfflineSigner("injective-1")
            .then(signer => signer.getAccounts())
            .then(accounts => {
                if (accounts && accounts.length > 0) {
                    connectKeplrWallet();
                }
            })
            .catch(console.error);
    }
});
