// Telegram WebApp functionality
// This script provides integration with the Telegram Mini App platform

// Store the Telegram WebApp instance
let tg = window.Telegram.WebApp;

// Initialize the Telegram WebApp
function initTelegramWebApp() {
    // Expand the Web App to take the full screen
    tg.expand();

    // Set the main button to be visible
    tg.MainButton.isVisible = false;

    // Set the theme colors and styles based on Telegram's theme
    document.documentElement.style.setProperty('--tg-theme-bg-color', tg.themeParams.bg_color || '#1E1E1E');
    document.documentElement.style.setProperty('--tg-theme-text-color', tg.themeParams.text_color || '#FFFFFF');
    document.documentElement.style.setProperty('--tg-theme-hint-color', tg.themeParams.hint_color || '#999999');
    document.documentElement.style.setProperty('--tg-theme-link-color', tg.themeParams.link_color || '#2AABEE');
    document.documentElement.style.setProperty('--tg-theme-button-color', tg.themeParams.button_color || '#2AABEE');
    document.documentElement.style.setProperty('--tg-theme-button-text-color', tg.themeParams.button_text_color || '#FFFFFF');
}

// Show the main button with custom text and callback
function showMainButton(text, callback) {
    tg.MainButton.setText(text);
    tg.MainButton.onClick(callback);
    tg.MainButton.show();
}

// Hide the main button
function hideMainButton() {
    tg.MainButton.hide();
}

// Send data back to the Telegram Bot
function sendData(data) {
    tg.sendData(JSON.stringify(data));
}

// Close the Web App
function closeApp() {
    tg.close();
}

// Handle back button press - using in-app buttons only
function handleBackButton(callback) {
    // Add event listeners to all back buttons in the UI
    document.querySelectorAll('.back-btn').forEach(btn => {
        // Clone and replace to remove old event listeners
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        // Add new event listener
        newBtn.addEventListener('click', callback);
    });
}

// Show the back button - we only use visible UI buttons
function showBackButton() {
    // Show the back button container
    const backBtnContainer = document.getElementById('back-btn-container');
    if (backBtnContainer) {
        backBtnContainer.style.display = 'block';
    }
}

// Hide the back button - we only use visible UI buttons
function hideBackButton() {
    // Hide the back button container
    const backBtnContainer = document.getElementById('back-btn-container');
    if (backBtnContainer) {
        backBtnContainer.style.display = 'none';
    }
}

// Get user info
function getUserInfo() {
    return tg.initDataUnsafe && tg.initDataUnsafe.user 
        ? tg.initDataUnsafe.user 
        : null;
}

// Export Telegram WebApp functions
window.TelegramWebApp = {
    init: initTelegramWebApp,
    showMainButton,
    hideMainButton,
    sendData,
    closeApp,
    handleBackButton,
    showBackButton,
    hideBackButton,
    getUserInfo,
    tg // direct access to the original Telegram WebApp object
};

// Initialize when the document is loaded
document.addEventListener('DOMContentLoaded', initTelegramWebApp);
