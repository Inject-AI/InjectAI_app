// Main application JavaScript

// DOM Elements
const marketSection = document.getElementById('market-section');
const marketContainer = document.getElementById('market-container');
const analysisSection = document.getElementById('analysis-section');
const analysisForm = document.getElementById('analysis-form');
const analysisResult = document.getElementById('analysis-result');
const showMarketBtn = document.getElementById('show-market-btn');
const showAnalysisBtn = document.getElementById('show-analysis-btn');
const homeSection = document.getElementById('home-section');

// Hide all sections initially except home
marketSection.style.display = 'none';
analysisSection.style.display = 'none';

// Navigation Functions
showMarketBtn.addEventListener('click', () => {
    homeSection.style.display = 'none';
    marketSection.style.display = 'block';
    loadMarketData();
});

showAnalysisBtn.addEventListener('click', () => {
    homeSection.style.display = 'none';
    analysisSection.style.display = 'block';
});

// Market Data Loading
async function loadMarketData() {
    try {
        const response = await fetch('/api/market_data');
        if (!response.ok) throw new Error('Failed to fetch market data');
        const data = await response.json();
        displayMarketData(data);
    } catch (error) {
        marketContainer.innerHTML = `
            <div class="alert alert-danger">
                Error loading market data: ${error.message}
            </div>
        `;
    }
}

function displayMarketData(data) {
    let html = '<div class="row">';

    // First display INJ if available
    if (data.injective) {
        html += createCryptoCard('injective', data.injective, true);
    }

    // Display other cryptocurrencies
    for (const [cryptoId, cryptoData] of Object.entries(data)) {
        if (cryptoId !== 'injective') {
            html += createCryptoCard(cryptoId, cryptoData);
        }
    }

    html += '</div>';
    marketContainer.innerHTML = html;
}

function createCryptoCard(cryptoId, data, featured = false) {
    const price = data.usd || 0;
    const change24h = data.usd_24h_change || 0;
    const marketCap = data.usd_market_cap || 0;
    const volume = data.usd_24h_vol || 0;

    return `
        <div class="col-12 ${featured ? 'mb-4' : 'col-md-6 mb-3'}">
            <div class="card crypto-card ${featured ? 'featured' : ''}">
                <div class="card-body">
                    <h5 class="card-title">
                        ${featured ? '⭐ ' : ''}${cryptoId.toUpperCase()}
                    </h5>
                    <div class="price-info">
                        <h3>$${price.toFixed(2)}</h3>
                        <span class="change-24h ${change24h >= 0 ? 'text-success' : 'text-danger'}">
                            ${change24h >= 0 ? '▲' : '▼'} ${Math.abs(change24h).toFixed(2)}%
                        </span>
                    </div>
                    <div class="market-stats">
                        <div>Market Cap: $${(marketCap / 1e6).toFixed(2)}M</div>
                        <div>24h Volume: $${(volume / 1e6).toFixed(2)}M</div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Analysis Form Handling
analysisForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const question = document.getElementById('analysis-question').value;

    analysisResult.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"></div></div>';

    try {
        const response = await fetch('/api/analysis', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question })
        });

        if (!response.ok) throw new Error('Failed to get analysis');
        const data = await response.json();

        analysisResult.innerHTML = `
            <div class="analysis-result-container">
                <h5>Analysis Result:</h5>
                <p>${data.analysis}</p>
            </div>
        `;
    } catch (error) {
        analysisResult.innerHTML = `
            <div class="alert alert-danger">
                Error getting analysis: ${error.message}
            </div>
        `;
    }
});

// Initialize Telegram WebApp
function initTelegramWebApp() {
    window.TelegramWebApp.init();
}


// Initialize the app when the document is loaded
document.addEventListener('DOMContentLoaded', function() {
    initTelegramWebApp();
    showSection('home-section');
});

// Show/hide sections
function showSection(sectionId) {
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';

    // Show/hide back button
    document.getElementById('back-btn-container').style.display =
        sectionId === 'home-section' ? 'none' : 'block';
}

//Show crypto details (This function remains largely unchanged as it's handled by the new approach)
async function showCryptoDetails(symbol) {
    showSection('market-detail-section');
    const container = document.getElementById('crypto-detail-container');

    try {
        const response = await fetch(`/market_details/${symbol}`);
        const data = await response.json();
        displayCryptoDetails(data);
    } catch (error) {
        container.innerHTML = '<div class="alert alert-danger">Failed to load details</div>';
    }
}

// Display crypto details (This function remains largely unchanged as it's handled by the new approach)
function displayCryptoDetails(data) {
    const container = document.getElementById('crypto-detail-container');

    container.innerHTML = `
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">${data.name} (${data.symbol.toUpperCase()})</h5>
                <p class="card-text">Current Price: $${data.current_price.toLocaleString()}</p>
                <p class="card-text">Market Cap: $${data.market_cap.toLocaleString()}</p>
                <p class="card-text">24h Volume: $${data.total_volume.toLocaleString()}</p>
                <p class="card-text">24h High: $${data.high_24h.toLocaleString()}</p>
                <p class="card-text">24h Low: $${data.low_24h.toLocaleString()}</p>
            </div>
        </div>
    `;
}

// Handle analysis submit (This function is largely replaced by the new event listener)
//This function is kept for backward compatibility with the original HTML structure, but it's functionality is largely superseded by the improved analysis handling

async function handleAnalysisSubmit() {
    const question = document.getElementById('analysis-question').value;
    const resultContainer = document.getElementById('analysis-result');

    resultContainer.innerHTML = `
        <div class="text-center">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;

    try {
        const response = await fetch('/analysis', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question })
        });

        const data = await response.json();
        resultContainer.innerHTML = `
            <div class="analysis-result">
                <p>${data.analysis}</p>
            </div>
        `;
    } catch (error) {
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                Failed to get analysis. Please try again.
            </div>
        `;
    }
}

//Setup Navigation Handlers (This is largely replaced by the improved navigation handlers)
//This function is kept for backward compatibility, but it's functionality is largely superseded by the improved navigation handling in the edited code
function setupNavigationHandlers() {
    document.getElementById('show-market-btn').addEventListener('click', () => {
        showSection('market-section');
        loadMarketData();
    });

    document.getElementById('show-analysis-btn').addEventListener('click', () => {
        showSection('analysis-section');
    });

    // Back button handler
    document.querySelector('.back-btn').addEventListener('click', () => {
        showSection('home-section');
    });

    // Analysis form submission
    document.getElementById('analysis-form').addEventListener('submit', (e) => {
        e.preventDefault();
        handleAnalysisSubmit();
    });
}