import os

# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "7756865731:AAEw3RtQSQcWK_RatJoh8s4aRfYHtjwigPg")

# CoinGecko API Configuration
COINGECKO_API_KEY = os.environ.get("COINGECKO_API_KEY", "CG-cmLey4efgLR8T2kAB5d7pZQs")
COINGECKO_API_URL = "https://api.coingecko.com/api/v3"

# Mistral API Configuration
MISTRAL_API_KEY = os.environ.get("MISTRAL_API_KEY", "kG9V1fdRlMK26SdKGoGU6FkrcAG15Axd")
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"

# Common cryptocurrencies to display
CRYPTOCURRENCIES = [
    "bitcoin", "ethereum", "injective", "ripple", "cardano", "solana", 
    "polkadot", "dogecoin", "shiba-inu", "litecoin", "chainlink"
]
